import "./globals.css";

export const metadata = {
  title: "My Onchain",
  description: "A clean Ethereum wallet dashboard",
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}