"use client";

import { useState } from "react";
import { Wallet, ArrowUpRight, ArrowDownLeft, Copy, ExternalLink, ShieldCheck, Activity, ChevronDown } from "lucide-react";

const demoAddress = "0x71C7...9A2F";

export default function Dashboard() {
  const [connected, setConnected] = useState(false);
  const [network, setNetwork] = useState("Ethereum");
  const [copied, setCopied] = useState(false);

  async function connectWallet() {
    if (typeof window !== "undefined" && window.ethereum) {
      try {
        await window.ethereum.request({ method: "eth_requestAccounts" });
        setConnected(true);
      } catch {}
    } else {
      setConnected(true); // demo mode until a wallet provider is installed
    }
  }

  function copyAddress() {
    navigator.clipboard?.writeText("0x71C7A0B1D3E49A2F");
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }

  return (
    <main>
      <header className="nav">
        <div className="brand"><div className="logo">◆</div><span>My Onchain</span></div>
        <div className="navRight">
          <div className="network"><span className="dot"></span>{network}<ChevronDown size={15}/></div>
          <button className="connect" onClick={connectWallet}>
            <Wallet size={17}/> {connected ? demoAddress : "Connect Wallet"}
          </button>
        </div>
      </header>

      <section className="hero">
        <div>
          <p className="eyebrow">ONCHAIN DASHBOARD</p>
          <h1>Your wallet, <span>simplified.</span></h1>
          <p className="sub">Track your Ethereum assets and activity from one clean, non-custodial dashboard.</p>
          <div className="heroActions">
            <button className="primary" onClick={connectWallet}><Wallet size={18}/> {connected ? "Wallet Connected" : "Connect Wallet"}</button>
            <button className="secondary" onClick={() => document.getElementById("activity").scrollIntoView({behavior:"smooth"})}>View activity</button>
          </div>
        </div>
        <div className="orbCard">
          <div className="orb">Ξ</div>
          <div><strong>Ethereum</strong><small>Secure on-chain data</small></div>
          <ShieldCheck size={20}/>
        </div>
      </section>

      <section className="grid">
        <article className="card balance">
          <div className="cardTop"><span>Total balance</span><span className="badge">Demo data</span></div>
          <h2>$8,426.18</h2>
          <div className="positive">+$284.22 <span>+3.49% today</span></div>
          <div className="miniChart"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </article>

        <article className="card">
          <div className="cardTop"><span>Assets</span><Activity size={18}/></div>
          <div className="asset"><div className="coin eth">Ξ</div><div><b>Ethereum</b><small>ETH</small></div><strong>1.84 ETH</strong></div>
          <div className="asset"><div className="coin usdt">$</div><div><b>Tether</b><small>USDT</small></div><strong>5,120 USDT</strong></div>
          <div className="asset"><div className="coin usdc">$</div><div><b>USD Coin</b><small>USDC</small></div><strong>1,920 USDC</strong></div>
        </article>
      </section>

      <section className="actionGrid">
        <button className="action"><ArrowUpRight/><b>Send</b><small>Transfer an asset</small></button>
        <button className="action"><ArrowDownLeft/><b>Receive</b><small>Get your wallet address</small></button>
        <button className="action"><ExternalLink/><b>Explorer</b><small>Open on Etherscan</small></button>
      </section>

      <section className="activity" id="activity">
        <div className="sectionTitle"><div><p className="eyebrow">RECENT</p><h3>Activity</h3></div><button className="viewAll">View all</button></div>
        {[
          ["Received ETH","0.42 ETH","Today, 10:42","+$1,624.10"],
          ["USDT transfer","1,000 USDT","Yesterday, 18:09","-$1,000.00"],
          ["Received USDC","750 USDC","Sep 22, 14:30","+$750.00"]
        ].map((x,i)=><div className="tx" key={i}><div className={"txIcon "+(i===1?"out":"")} >{i===1?<ArrowUpRight/>:<ArrowDownLeft/>}</div><div className="txMain"><b>{x[0]}</b><small>{x[2]}</small></div><div className="txAsset">{x[1]}</div><strong className={i===1?"red":"green"}>{x[3]}</strong></div>)}
      </section>

      <footer><span>© 2026 My Onchain</span><span>Non-custodial interface · Demo version</span><button onClick={copyAddress}><Copy size={14}/> {copied ? "Copied" : "Copy demo address"}</button></footer>
    </main>
  );
}